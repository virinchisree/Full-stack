package com.contact;

public interface Constants {
    String DRIVER = "org.hsqldb.jdbcDriver";
    String URL = "jdbc:hsqldb:hsql://localhost/";
    String UID = "SA";
    String PWD = "";
    String SUCCESS = "success";
}
