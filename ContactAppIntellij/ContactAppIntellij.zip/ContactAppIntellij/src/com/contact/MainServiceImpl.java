package com.contact;

public class MainServiceImpl implements MainService {
    @Override
    public String Addcontact(AddBean bean) {

        return Constants.SUCCESS;
    }
}
