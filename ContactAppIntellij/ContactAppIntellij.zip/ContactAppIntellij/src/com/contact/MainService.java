package com.contact;

import org.springframework.stereotype.Service;

@Service
public interface MainService {

    public String Addcontact(AddBean bean);
}
